/****************************************************************************
 *  Copyright: National ICT Australia,  2007 - 2011                         *
 *  Developed at the ATP lab, Networked Systems research theme              *
 *  Author(s): Athanassios Boulis, Yuriy Tselishchev                        *
 *  This file is distributed under the terms in the attached LICENSE file.  *
 *  If you do not find this file, copies can be found by writing to:        *
 *                                                                          *
 *      NICTA, Locked Bag 9013, Alexandria, NSW 1435, Australia             *
 *      Attention:  License Inquiry.                                        *
 *                                                                          *
 ****************************************************************************/


#include "ThroughputTest.h"
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <iostream>
#include <random>
#include <fstream>
#include <algorithm>
#include <string>
#include <sstream>
#include <vector>
#include <simtime.h>

Define_Module(ThroughputTest);

using namespace std;


double janela_temperatura[55][3000] = {0};
double janela_umidade[55][3000] = {0};
double janela_leitura[55][3000] = {0};
int contadorleitura[55] = {1};

int contador_envio_pacotes[55];
int contador_geral[10] = {0};
int sem_diferenca[10] = {0};
int janela_atual[10] = {0};

int vizinhos[10][6] = 
	{	
	{2,3,4,6},
	{7,9,10,11,53,8},
	{12,13,14,16},
	{17,18,20,21},
	{22,23,25,26,27},
	{29,30,31,32},
	{1,33,34,36,37},
	{38,39,41,42,43},
	{44,46,47},
	{48,49,50,52}
	};

double historico_temperatura[55][3000] = {0};
int tamanho[10] = {4,6,4,4,5,4,5,5,3,4};
vector<int> diferente[10]; 
int numero = 0;
int leitura[55];



int segundos_vizinhanca[55]  = {8,1,2,3,4,5,5,1,2,3,4,5,1,2,3,4,5,1,2,3,4,5,1,2,3,4,5,6,1,2,3,4,5,2,3,4,5,6,1,2,3,4,5,6,1,2,3,4,1,2,3,4,5,6,7};
double viz[55] = {0,0.1,0.1,0.1,0.1,0.1,0.1,0.2,0.2,0.2,0.2,0.2,0.3,0.3,0.3,0.3,0.3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0.4,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0.2,0.2};
void ThroughputTest::Historico( int numero_vizinhos, int no, int pos){
			
		
		
			
			int  n_samples = 0;
			string file_results_name = "arquivo_results.txt";
		    string results_file = "final_results.txt";
			
			ofstream send_data;
			send_data.open(file_results_name);	
		  
		    
		   int historicototal = 0;
		    for (int i = 0; i < numero_vizinhos; i++){
				int node = vizinhos[pos][i];
				//trace() << "Nó enviado: " << node;
				//trace() << "Leitura: " << janela_atual[pos];
				historicototal+= janela_atual[pos];
				//trace() << "Pos: " << pos;
				for (int j = 0; j < janela_atual[pos]; j++){
					if (pos == 5 or pos == 6){
					//trace() << "Node: " << node;
					//trace() << "Historico: " << historico_temperatura[node][j];
					}
					send_data << historico_temperatura[node][j] << "," << node << "," << diferente[pos][i] << "," << node << endl;
					
				}				
			}	
			
				
			
			send_data.close();
			
			
			  
			
			int x = janela_atual[pos];			
			stringstream sstm;
			sstm << x;
					
			stringstream ss;
			ss << tamanho[pos];
			
			
			stringstream novoss;
			novoss << historicototal;
									
			string command = "python3.6 deteccao_anomalia2.py < "+file_results_name+" > "+results_file+" "+sstm.str()+" "+ss.str()+" "+novoss.str();
			system(command.c_str()); 
			trace() << command << endl;
			
			ifstream file_results(results_file);
			string line;
			
			if (file_results.is_open()){
				//coloca todas as linhas do arquivo na saída
				while ( getline (file_results,line) ) {
		
					trace() << line << endl;
					
							 //se quiser converter para double
				}
					
			
			
			file_results.close();
	
			}
			
	
	
	
}




void ThroughputTest::DeteccaoEspacial(int numero_vizinhos, int janela, int no, int pos) {
			
			
			
			int  n_samples = 0;
			string file_results_name = "novo_arquivo.txt";
		    string results_file = "final_results2.txt";
			
			ofstream send_data;
			send_data.open(file_results_name);	
		    //trace() << "CONTADOR ENVIO PACOTES: " << contador_envio_pacotes[no];
		    for (int i = 0; i< numero_vizinhos; i++){
				
				for (int j = 0; j < contador_envio_pacotes[no]; j++){
					int node = vizinhos[pos][i];
					send_data << janela_leitura[node][j] << "," << janela_temperatura[node][j] << "," << janela_umidade[node][j] << "," << node << endl;
					
				}				
			}	
	
			
	
	
			janela_atual[pos]+= janela;
			send_data.close();
						
			stringstream sstm;
			sstm << janela;
			
			stringstream ss;
			ss << numero_vizinhos;
									
			string command = "python3.6 deteccao_anomalia.py < "+file_results_name+" > "+results_file+" "+sstm.str()+" "+ss.str() ;
			system(command.c_str()); 
			trace() << command << endl;
			
			ifstream file_results(results_file);
			string line;
			
			if (file_results.is_open()){
				//coloca todas as linhas do arquivo na saída
				while ( getline (file_results,line) ) {
					int i = stoi(line);
					trace() << line << endl;
					
					diferente[pos].push_back(i);
					
							 //se quiser converter para double
				}
					
			
			
			file_results.close();
	
			}
	
	
	
		for (int j = 0; j < diferente[pos].size(); j++){
		
			if (diferente[pos][j] != 0 and diferente[pos][j] != 22){
			
			sem_diferenca[pos]++;
			
			}
			
			if (diferente[pos][0] == 22){
			
			diferente[pos].clear();
			
			trace() << "Evento ocorreu na Janela: " << janela_atual[pos] << "Vizinhanca: " << pos;
			
			
			}
			
		}
		
		
		
		
		
		
	
	
       
	
	
	
	
	
	}

void ThroughputTest::startup()
{
//	srand(time(NULL));
	packet_rate = par("packet_rate");
	recipientAddress = par("nextRecipient").stringValue();
	startupDelay = par("startupDelay");
	

	double startupDelay_rand = 0;//rand()%10;
	
	packet_spacing = packet_rate > 0 ? 5.0 / float (packet_rate) : -1;
	dataSN = 1;
	
	 
	string addr(SELF_NETWORK_ADDRESS);
	int node_id = stoi(addr);
	
	
	
	
	
	
	int no = abs(recipientAddress.compare(SELF_NETWORK_ADDRESS));
    
    
	
	
	if (packet_spacing > 0) {
		setTimer(SEND_PACKET, ((segundos_vizinhanca[node_id])+viz[node_id]));
	}
	else
		// Diego
		trace() << "Not sending packets";
	//trace() << "Nó: " << nodeId;
	//trace() << simTime().dbl();
	

	declareOutput("Packets received per node");
	for(int i = 0; i < 5; i++)new_value_flqe[i]=false;
}


void ThroughputTest::fromNetworkLayer(DataPacket * rcvPacket,
		const char *source, double rssi, double lqi)
{
	int sequenceNumber = rcvPacket->getSequenceNumber();
	double* data = rcvPacket->getDataPacket();
	
    //trace() << "Received packet " << sequenceNumber << " from node " << source << ": " << rssi << " " << lqi << " fromNetworkLayer";
	//trace() << "No: " <<  data[6];

	//SINK NODE
	string addr(SELF_NETWORK_ADDRESS);
	//trace() << "ADDR: " << addr;
	
	
	
	
	
	if (addr.compare("0") == 0) {
		
		
		int id = data[6];
		int lect = data[5];
		int pos = data[7];
		int comparacao = data[8];
		historico_temperatura[id][lect-1] = data[3];
		leitura[id] = lect;
		
		if (comparacao > 0){

			
			Historico(tamanho[pos],id,pos);
			
		}
	
	trace() << "Sensor: " << data[6];
	trace () << "CH: " << source;
	
	}
			

	
	
			
    if (addr.compare("24") == 0){
			int id = data[6];
			int pos = data[7];
		
			int dissimilar = 0;
			double *pacote = new double[10];
			janela_temperatura[id][contador_envio_pacotes[id]-1] = data[3];
			janela_leitura[id][contador_envio_pacotes[id]-1] = data[5];
			janela_umidade[id][contador_envio_pacotes[id]-1] = data[4];
			
			
			pacote[0] = data[0];
			pacote[1] = data[1];
			pacote[2] = data[2];
            pacote[3] = data[3];
            pacote[4] = data[4];
			pacote[5] = data[5];
			pacote[6] = data[6];
			pacote[7] = data[7];
			
			
			if (contador_geral[pos] != 0){
				if (contador_geral[pos] == tamanho[pos] or  contador_geral[pos] % tamanho[pos] == 0){
					DeteccaoEspacial(tamanho[pos],contador_envio_pacotes[id],id,pos);
					if (diferente[pos].empty() == false and sem_diferenca[pos] == 0){
						
						
						trace() << "Não existe diferença entre os nós";
						pacote[8] = dissimilar;
						trace() << "Nó final: " << source;
						trace() << "Clusterhead: " << addr;
						packets_sent++; 
						DataPacket* data_packet = createDataPacket(pacote, dataSN, 80);
						toNetworkLayer(data_packet, (const char*)("0"));
						dataSN++;
						packets_received++;
						contador_geral[pos] = 0;		
						for(int  i;  i<tamanho[pos]; i++){
							int node = vizinhos[pos][i];
							contador_envio_pacotes[node] = 0;}
								
						diferente[pos].clear();
	
					} 
					else if (diferente[pos].empty() == false and sem_diferenca[pos] != 0){
							
							dissimilar++;
							pacote[8] = dissimilar;
							trace() << "Nó final: " << source;
							trace() << "Clusterhead: " << addr;
							packets_sent++; 
							DataPacket* data_packet = createDataPacket(pacote, dataSN, 80);
							toNetworkLayer(data_packet, (const char*)("0"));
							dataSN++;
							packets_received++;
							trace() << "Possui diferentes";
							contador_geral[pos] = 0;
							for(int  i;  i<tamanho[pos]; i++){
								
								int node = vizinhos[pos][i];
								contador_envio_pacotes[node] = 0;}
					
							diferente[pos].clear();
							sem_diferenca[pos] = 0;
					}
					
					else if(diferente[pos].empty() == true){	
							trace() << "Não se achou anomalia";
							contador_geral[pos] = 0;
							for(int  i;  i<tamanho[pos]; i++){
								int node = vizinhos[pos][i];
								contador_envio_pacotes[node] = 0;}
							pacote[8] = dissimilar;
							trace() << "Nó final: " << source;
							trace() << "Clusterhead: " << addr;
							packets_sent++; 
							DataPacket* data_packet = createDataPacket(pacote, dataSN, 80);
							toNetworkLayer(data_packet, (const char*)("0"));
							dataSN++;
							packets_received++;
					}
				
				} else{
					pacote[8] = dissimilar;
					trace() << "Os pacotes iniciais";
					trace() << "Nó final: " << source;
					trace() << "Clusterhead: " << addr;
					packets_sent++; 
					DataPacket* data_packet = createDataPacket(pacote, dataSN, 80);
					toNetworkLayer(data_packet, (const char*)("0"));
					dataSN++;

			
				packets_received++;
			
				}
			}
			else{
					pacote[8] = dissimilar;
					trace() << "Os pacotes iniciais";
					trace() << "Nó final: " << source;
					trace() << "Clusterhead: " << addr;
					packets_sent++; 
					DataPacket* data_packet = createDataPacket(pacote, dataSN, 80);
					toNetworkLayer(data_packet, (const char*)("0"));
					dataSN++;

			
				packets_received++;
			
				}
			
}
}
void ThroughputTest::timerFiredCallback(int index)
{
	
	switch (index){
		case SEND_PACKET: {
			 
			string addr(SELF_NETWORK_ADDRESS);
			int node_id = stoi(addr);
			int timing;
			
			//is an END NODE
			if (addr.compare("0") != 0 && addr.compare("28") != 0 && addr.compare("54") != 0 && addr.compare("15") != 0 && addr.compare("19") != 0 && addr.compare("24") != 0 && addr.compare("35") != 0 && addr.compare("40") != 0  && addr.compare("45") != 0 && addr.compare("51") != 51 ) {
				
				
				int nodeId = stoi(SELF_NETWORK_ADDRESS);
				
				contador_envio_pacotes[nodeId]++;
				//trace() << "Contador do nó: " << nodeId << " " <<  contador_envio_pacotes[nodeId];
				
					
				
				string cenario = "/home/sdn/Vizinhanca5/Experimentacao/No_";
				string dados_file =  cenario+addr+".txt";
				trace() << "Sending packet (nó"<< " " << addr << ")" << dataSN;
				//trace() << "Contador Geral: " << contador_geral;
				
				packets_sent++;
  
				ifstream file_results(dados_file.c_str());
	
				string line;
	
               
				double *data = new double[10];
				int leitura, ano, mes, data1, hora, minuto, epoca, no, rotulo, leitura_inutil;
				double segundo, temperatura, umidade;
				
                if (file_results.is_open()){
					
					
					
					while ( getline (file_results,line) ) {
						
						sscanf(line.c_str(),"%d,%d,%lf,%lf,%d", &leitura,&no, &temperatura, &umidade, &rotulo);
						
							 //trace() << "Leitura: " << leitura
							
							
							
		                     if (leitura == contadorleitura[no] + 1){
								 
									
                                //     trace()<< "entrou aqui dentro do leitura";
                                     data[0] = 0;
				                     data[1] = prr_beacon_end;
				                     data[2] = RNP;
                                     data[3] = temperatura;
                                     data[4] = umidade;
									 data[5] = leitura;
									 data[6] = no;
									// data[7] = 0;

		  
                                    									
									
									

									if (no > 1 and no < 7){
										data[7] = 0;
										if  (contador_envio_pacotes[no] >= 30){
										
											contador_geral[0]++;
											
											
					
										}
										
									
										trace() << "Origem Clusterhead 5";
										DataPacket* data_packet = createDataPacket(data, dataSN, 80);
										toNetworkLayer(data_packet, (const char*)("5"));
										timing = 5;
									} 
									
									
									
									if (no > 6 and no < 12 or no == 53 ) {
										data[7] = 1;
										if  (contador_envio_pacotes[no] == 30){
											contador_geral[1]++;
											
										
					
										}
										trace() << "Origem Clusterhead 54";
										DataPacket* data_packet = createDataPacket(data, dataSN, 80);
										toNetworkLayer(data_packet, (const char*)("54"));
										timing = 7;
									} 
									
									if (no >=12 and no < 17){
										data[7] = 2;
										if  (contador_envio_pacotes[no] == 30){
											contador_geral[2]++;
											
											
					
										}
										trace() << "Origem Clusterhead 15";
										DataPacket* data_packet = createDataPacket(data, dataSN, 80);
										toNetworkLayer(data_packet, (const char*)("15"));
										timing = 9;
									} 
									
									if (no > 16 and no < 22){
										data[7] = 3;
										if  (contador_envio_pacotes[no] == 30){
											contador_geral[3]++;
											
											
					
										}
										trace() << "Origem Clusterhead 19";
										DataPacket* data_packet = createDataPacket(data, dataSN, 80);
										toNetworkLayer(data_packet, (const char*)("19"));
										
										timing = 11;
									} 
									
									if (no >=22 and no < 28){
										data[7] = 4;
										if  (contador_envio_pacotes[no] == 30){
											contador_geral[4]++;
										
											
					
										}
										trace() << "Origem Clusterhead 24";
										DataPacket* data_packet = createDataPacket(data, dataSN, 80);
										toNetworkLayer(data_packet, (const char*)("24"));
										timing = 13;
									} 
									
									
									
									if (no > 28 and no < 33){
										data[7] = 5;
										if  (contador_envio_pacotes[no] == 30){
											contador_geral[5]++;
											
											
					
										}
										trace() << "Origem Clusterhead 28";
										DataPacket* data_packet = createDataPacket(data, dataSN, 80);
										toNetworkLayer(data_packet, (const char*)("28"));
										
										timing = 15;
									} 
									
									 if (no >= 33 and no < 38 or no == 1){
										 data[7] = 6;
										if  (contador_envio_pacotes[no] == 30){
											contador_geral[6]++;
											
											
					
										}
										trace() << "Origem Clusterhead 35";
										DataPacket* data_packet = createDataPacket(data, dataSN, 80);
										toNetworkLayer(data_packet, (const char*)("35"));
										timing = 17;
									} 
									
									if (no >= 38 and no <= 43){
										data[7] = 7;
										if  (contador_envio_pacotes[no] == 30){
											contador_geral[7]++;
											
											
					
										}
										trace() << "Origem Clusterhead 40";
										DataPacket* data_packet = createDataPacket(data, dataSN, 80);
										toNetworkLayer(data_packet, (const char*)("40"));
										
										timing = 19;
									} 
									
									if (no >= 44 and no <= 47){
										data[7] = 8;
										if  (contador_envio_pacotes[no] == 30){
											contador_geral[8]++;
											

										}
										trace() << "Origem Clusterhead 45";
										DataPacket* data_packet = createDataPacket(data, dataSN, 80);
										toNetworkLayer(data_packet, (const char*)("45"));
										
										timing = 21;
									} 
									
									if (no >= 48 and no <= 50 or no == 52){
										
										data[7] = 9;
										if  (contador_envio_pacotes[no] == 30){
											contador_geral[9]++;
											

										}
										trace() << "Geral: " << contador_geral[9];
										trace() << "Origem Clusterhead 51";
										DataPacket* data_packet = createDataPacket(data, dataSN, 80);
										toNetworkLayer(data_packet, (const char*)("51"));
										
										timing = 23;
									} 
                                  
                                    
                                    dataSN++;
                                    cont_tx++;
                                    contadorleitura[no]++;
							
									break;
                                    
								}
							
							
                             
	                 }

				 }
					
					
				file_results.close();
				setTimer(SEND_PACKET,5);
				
				/*
				if (no > 1 and no < 7){
				setTimer(SEND_PACKET,5);
				}
				
				if (no > 6 and no < 12 or no == 53 or no == 54){
				setTimer(SEND_PACKET,7);
				}
				
				
				
				if (no >= 13 and no < 17){
				setTimer(SEND_PACKET,3);
				}
				
				
				if (no > 17 and no <= 22){
				setTimer(SEND_PACKET,9);
				}
				
				
				if (no >= 23 and no < 28){
				setTimer(SEND_PACKET,11);
				}
				
				/*
				if (no > 27 and no < 34){
				setTimer(SEND_PACKET,13);
				}
				
				
				if (no >= 34 and no < 39){
				setTimer(SEND_PACKET,15);
				}
				
				
				if (no >= 39 and no <= 44){
				setTimer(SEND_PACKET,17);
				}
				
				
				if (no >= 46 and no <= 50){
				setTimer(SEND_PACKET,19);
				}
				
				if (no >= 51 and no <= 54){
				setTimer(SEND_PACKET,21);
				}
				*/
		 
	}
}
}
}

void ThroughputTest::sendAck(int packet_id)
{
	//trace() << "Sending ack for packet " << packet_id;
    double *data = new double[10];
	data[0] = packet_id;
	DataPacket* data_packet = createDataPacket(data, ack_seq, 5);  
	toNetworkLayer(data_packet, (const char*)("1"));
	acks_sent++;
	//trace() << "Acks sent: " << acks_sent;
}


// This method processes a received carrier sense interupt. Used only for demo purposes
// in some simulations. Feel free to comment out the trace command.
void ThroughputTest::handleRadioControlMessage(RadioControlMessage *radioMsg)
{
	switch (radioMsg->getRadioControlMessageKind()) {
		case CARRIER_SENSE_INTERRUPT:
			trace() << "CS Interrupt received! current RSSI value is: " << radioModule->readRSSI();
                        break;
	}
}

