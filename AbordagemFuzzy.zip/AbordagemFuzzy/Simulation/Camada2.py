import sys
import numpy as np
import pandas as pd
from sklearn.neighbors import LocalOutlierFactor
from sklearn import svm
from sklearn.covariance import EllipticEnvelope
from sklearn.impute import SimpleImputer
from scipy import stats
from sklearn.metrics import mean_squared_error
from math import sqrt
from statsmodels.tsa.arima_model import ARIMA
from scipy.stats import pearsonr
import skfuzzy as fuzz
import matplotlib.pyplot as plt
from skfuzzy import control as ctrl
import warnings
warnings.filterwarnings("ignore")
from pmdarima import auto_arima

nsamples = int(sys.argv[1]) #quantiade de valores no arquivo
nsamples1 = int(sys.argv[2])
nsamples2 = int(sys.argv[3])

def fuzzy(x,lista,z,node,pos,percent):
	#print(z)
	difer = (z/(len(lista)))*100
	correlacao_no = abs(x)*100
	
	vizinhos = 0
	
	for j in range(len(lista)):
		if j != pos:
			if (lista[j] >= 0.7):
				vizinhos+=1


	if (vizinhos == 0):
		percentual = 0
	else:
		percentual = (vizinhos/(len(lista)-1))*100

			#print(correlacao_no)
			#print(len(z))
			#print(percentual)

			#print("------------------------------------------------")


			
	Diferenca = ctrl.Antecedent(np.arange(0, 101, 1), 'Diferenca')
	Historico = ctrl.Antecedent(np.arange(0, 101, 1), 'Historico')
	Vizinhos = ctrl.Antecedent(np.arange(0, 101, 1), 'Vizinhos')

	#Diferenca.automf(names=['Correto', 'Não Definido','Falho'])

	Diferenca['Baixa'] = fuzz.trapmf(Diferenca.universe,[0, 0, 40, 50])
	Diferenca['Média'] = fuzz.trimf(Diferenca.universe,[40, 50,60])
	Diferenca['Alta'] = fuzz.trapmf(Diferenca.universe, [50, 60, 100,100])


	Historico['Fraca'] = fuzz.sigmf(Historico.universe,50,-1)
	Historico['Moderada'] = fuzz.pimf(Historico.universe,40,50,70,80)
	Historico['Forte'] = fuzz.sigmf(Historico.universe,70,1)

	#Vizinhos['Não-Correlacionados'] = fuzz.trapmf(Diferenca.universe,[0, 0, 40, 50])
	#Vizinhos['Não-Definido'] = fuzz.trapmf(Diferenca.universe,[40, 50, 60, 70])
	#Vizinhos['Correlacionados'] = fuzz.trimf(Diferenca.universe, [60, 100, 100])
	Vizinhos['Não-Correlacionados'] = fuzz.trimf(Vizinhos.universe,[0, 0, 40])
	Vizinhos['Não-Definido'] = fuzz.trimf(Vizinhos.universe,[30, 50, 70])
	Vizinhos['Correlacionados'] = fuzz.trimf(Vizinhos.universe, [60, 100, 100])

	Confianca = ctrl.Consequent(np.arange(0, 101, 1), 'Confianca')
	#Confianca.automf(names=['Não-Confiavel', 'Não-Definido', 'Confiavel'])
	Confianca['Não-Confiavel'] = fuzz.trimf(Confianca.universe,[0, 0, 40])
	Confianca['Não Definido'] = fuzz.trimf(Confianca.universe,[30, 50, 70])
	Confianca['Confiavel'] = fuzz.trimf(Confianca.universe, [60, 100, 100])



	rule1 = ctrl.Rule(Diferenca['Alta'] & Historico['Fraca'] & Vizinhos['Correlacionados'], Confianca['Não-Confiavel'])
	rule2 = ctrl.Rule(Diferenca['Baixa'] & Historico['Forte'] & Vizinhos['Correlacionados'], Confianca['Confiavel'] )
	rule3 = ctrl.Rule(Diferenca['Média'] & Historico['Moderada'] & Vizinhos['Não-Definido'], Confianca['Não Definido'] )
	rule4 = ctrl.Rule(Diferenca['Alta'] & Historico['Forte'] & Vizinhos['Não-Correlacionados'], Confianca['Confiavel'] )
	rule5 = ctrl.Rule(Diferenca['Baixa'] & Historico['Fraca'] & Vizinhos['Não-Correlacionados'], Confianca['Não-Confiavel'] )
	rule6 = ctrl.Rule(Diferenca['Alta'] & Historico['Fraca'] & Vizinhos['Não-Correlacionados'], Confianca['Não Definido'] )
	rule7 = ctrl.Rule(Diferenca['Alta'] & Historico['Fraca'] & Vizinhos['Não-Definido'], Confianca['Não-Confiavel'] )
	rule8 = ctrl.Rule(Diferenca['Média'] & Historico['Fraca'] & Vizinhos['Não-Correlacionados'], Confianca['Não Definido'] )
	rule9 = ctrl.Rule(Diferenca['Baixa'] & Historico['Forte'] & Vizinhos['Não-Correlacionados'], Confianca['Confiavel'] )
	rule10 = ctrl.Rule(Diferenca['Média'] & Historico['Forte'] & Vizinhos['Não-Correlacionados'], Confianca['Confiavel'] )
	rule11 = ctrl.Rule(Diferenca['Média'] & Historico['Fraca'] & Vizinhos['Correlacionados'], Confianca['Não-Confiavel'] )
	rule12 = ctrl.Rule(Diferenca['Alta'] & Historico['Forte'] & Vizinhos['Não-Definido'], Confianca['Confiavel'] )
	rule13 = ctrl.Rule(Diferenca['Baixa'] & Historico['Fraca'] & Vizinhos['Não-Definido'], Confianca['Não Definido'] )
	rule14 = ctrl.Rule(Diferenca['Média'] & Historico['Fraca'] & Vizinhos['Não-Definido'], Confianca['Não Definido'] )

	confianca_ctrl = ctrl.ControlSystem([rule1,rule2,rule3,rule4,rule5,rule6,rule7,rule8,rule9,rule10,rule11,rule12,rule13,rule14])
	confianca_simulador = ctrl.ControlSystemSimulation(confianca_ctrl)
	
	print("Diferenca: " + str(difer))
	print("Historico: " + str(correlacao_no))
	print("Vizinhos: " + str(percent))
	confianca_simulador.input['Diferenca'] = difer
	confianca_simulador.input['Historico'] = correlacao_no
	confianca_simulador.input['Vizinhos'] =  percent
	confianca_simulador.compute()

	print("Nó: " + str(node) + " Confianca: " + str(confianca_simulador.output['Confianca']) + " Janela: " + str(nsamples) )
	print(confianca_simulador.output['Confianca'])
	print("------------------------------------------------")




def Arima(no,limite_min,historico_temperatura):
	
	n = len(historico_temperatura)
	
	treino = historico_temperatura[:n-limite_min]
	
	
	#y = np.reshape(treino,(-1, 1))
	
	#imp = SimpleImputer(missing_values = 0, strategy="median")
	#x = imp.fit_transform(y)
	
	#train = list(x.flatten())
	

	teste = historico_temperatura[n-limite_min:]
	
	#z = np.reshape(teste,(-1, 1))
	#imp = SimpleImputer(missing_values = 0, strategy="median")
	#g = imp.fit_transform(z)
	
	
	#test = list(g.flatten())
	
	
	history = [x for x in treino]
	
	predictions = list()
	for t in range(len(teste)):
		model = ARIMA(history, order=(1,1,0))
		model_fit = model.fit(disp=0)
		output = model_fit.forecast()
		yhat = output[0]
		predictions.append(yhat)
		obs = teste[t]
		history.append(obs)
	
	pred = np.array(predictions) 

	
	pred = pred.flatten()
	test1 = np.array(teste)
	
	
	corr = np.corrcoef(test1, pred)
	
	
	return corr[0][1]

def correlacao(vetor,node,vizinho):
	espacial = []
	for j in range(vizinho):
		direcao1 = 0
		direcao2 = 0
		if j != node:
			mt = matriz[j] 
			
			R1 = np.corrcoef(vetor,mt)
			
			if (abs(R1[0][1])) <= 0.3:
				 espacial.append(j)
	
	
	return espacial


temperatura = []
umidade = []
diferente = [] 
no = []
matriz = []	




for i in range(nsamples2):
	
    d = input()
    dado = d.split(",")
    

    temperatura.append(float(dado[0]))
    no.append(int(dado[1]))
    diferente.append(float(dado[2]))
    
    



nodes = list(set(no))
resultado_correlação = []
difer = []


for i in nodes:
	 
	historico_temperatura = []
	dif = []
	for j in range(len(no)):
		
		if i == no[j]:
			historico_temperatura.append(temperatura[j])
			dif.append(diferente[j])
	n = len(historico_temperatura)

	resh = np.reshape(historico_temperatura,(-1, 1))
	imp = SimpleImputer(missing_values = 0, strategy="median")
	impfit = imp.fit_transform(resh)
	historico_temperatura = list(impfit.flatten())
	janela = historico_temperatura[n-30:]
	matriz.append(janela)
	ari = Arima(i,30,historico_temperatura) 
	setdif = list(set(dif)) 
	resultado_correlação.append(ari)
	difer.append(setdif[0])
	
	
"""
print("----------------------------_")
for i in nodes:
	print(i)
	lista = []
	for j in range(len(no)):
		if i == no[j]:
			lista.append(temperatura[j])
			
	n = len(lista)	
	print(n)
	print("---")
	janela = lista[n-50:]
	y = np.reshape(janela,(-1, 1))
	imp = SimpleImputer(missing_values = 0, strategy="median")
	x = imp.fit_transform(y)
	x = list(x.flatten())
	print(len(x))
	#print(len(x))
	print(x)
	matriz.append(x)
	print("aqui foi")

"""

		
		

for i in range(len(nodes)):
	
	check = 0
	lista1 = resultado_correlação
	print("VAI AGR OU NAO")
	diferentes = correlacao(matriz[i],i,len(nodes))
	print("foi")
	#print(diferentes)
	#print(lista1)
	for viz in diferentes:
		if lista1[viz] > 0.6:
			check+=1
	
	if (check == 0):
		percentual = 0
	else:
		percentual = (check/(len(diferentes)))*100		
		
	
		

	fuzzy(resultado_correlação[i],lista1,difer[i],nodes[i],i,percentual)
            

	


