import sys
import numpy as np
import pandas as pd
from sklearn.neighbors import LocalOutlierFactor
from sklearn import svm
from sklearn.covariance import EllipticEnvelope
from sklearn.impute import SimpleImputer
from scipy import stats




def correlacao(vetor,node,vizinho):
	
	espacial = 0
	for j in range(vizinho):
		direcao1 = 0
		direcao2 = 0
		if j != node:
			mt = matriz[j] 	
			R1 = np.corrcoef(vetor,mt)
			if (abs(R1[0][1])) <= 0.3:
				 espacial+=1
				
	
	
	return espacial
	


nsamples = int(sys.argv[1]) #quantiade de valores no arquivo

nsamples1 = int(sys.argv[2])

leitura = []
temperatura = []
umidade = []
no = []		
matriz = []



for i in range(nsamples*nsamples1):
	
	v = input()
	dado = v.split(",")
	
	leitura.append(int(dado[0]))
	temperatura.append(float(dado[1]))
	umidade.append(float(dado[2]))
	no.append(int(dado[3]))
	






limite_min = 0
limite_max = nsamples

for i in range(1,nsamples1+1):
	
    variavel = temperatura[limite_min:limite_max]
   
    y = np.reshape(variavel,(-1, 1))
    
    imp = SimpleImputer(missing_values = 0, strategy="median")
    x = imp.fit_transform(y)
    
    x = list(x.flatten())
    
    matriz.append(x)
    
    
    limite_min+=nsamples
    limite_max+=nsamples



lista = [0]*nsamples1
for j in range(nsamples1):
	
	contador = 0 
	analise = []
	x = stats.median_absolute_deviation(matriz[j])
	for i in matriz[j]:
		mi = 0.6745*(i - np.median(matriz[j]))/x
		analise.append(mi)
		
	for i in analise:
		if (abs(i) > 3.5):
			contador+=1
	
	if contador > 0:
		lista[j] = 1
		
	
	
	

y = sorted(set(no))

if 1 in lista:
	todos = 0
	for t in lista:
		if t == 1:
			todos+=1
	
	if (todos == len(lista)):
		
		dissimilaridade = []
		for i in range(nsamples1):
			diferentes = correlacao(matriz[i],i,nsamples1)
			dissimilaridade.append(diferentes)
		iguais = 0
		for t in dissimilaridade:
			if t == 0:
				iguais+=1
				
		if (iguais == len(dissimilaridade)):
			print(str(22))
		else:
			for i in range(dissimilaridade):
				print(str(i))
	else:
		for i in range(nsamples1):
			diferentes = correlacao(matriz[i],i,nsamples1)
			print(str(diferentes))
		
				
						
		
		
		
		
		 
	


